var searchData=
[
  ['vbegetmodeinfo_299',['vbeGetModeInfo',['../group___graphics.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;graphics.c'],['../group___graphics.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;graphics.c']]],
  ['vg_5finit_300',['vg_init',['../group___graphics.html#gaa6c1ff5024cd4d15e476bce487584daa',1,'vg_init(uint16_t mode):&#160;graphics.c'],['../group___graphics.html#gaa6c1ff5024cd4d15e476bce487584daa',1,'vg_init(uint16_t mode):&#160;graphics.c']]],
  ['vg_5fset_5fmode_301',['vg_set_mode',['../group___graphics.html#ga3eaed521041b153cd8f9c5d371b393ff',1,'vg_set_mode(uint16_t mode):&#160;graphics.c'],['../group___graphics.html#ga3eaed521041b153cd8f9c5d371b393ff',1,'vg_set_mode(uint16_t mode):&#160;graphics.c']]],
  ['visitedge_302',['visitEdge',['../group___graph.html#ga1a90331a7364d1dec99ab2b90b5e5266',1,'graph.c']]]
];
