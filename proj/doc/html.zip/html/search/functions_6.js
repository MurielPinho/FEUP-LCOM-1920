var searchData=
[
  ['initgame_268',['initGame',['../group___game.html#gaf914d9c0c56eba0cd037f32d5af60cf1',1,'initGame():&#160;game.c'],['../group___game.html#gaf914d9c0c56eba0cd037f32d5af60cf1',1,'initGame():&#160;game.c']]],
  ['initialize_5fpacket_269',['initialize_packet',['../group___p_s2.html#gaf0bd08b578b69f2f91bf42772b0da419',1,'initialize_packet(struct packet *pp, uint8_t packetBytes[]):&#160;ps2.c'],['../group___p_s2.html#gaf0bd08b578b69f2f91bf42772b0da419',1,'initialize_packet(struct packet *pp, uint8_t bytes[]):&#160;ps2.c']]],
  ['initmenu_270',['initMenu',['../group___menu.html#ga539fb5b0f1b763dc1cf8d6501160b2ce',1,'initMenu():&#160;menu.c'],['../group___menu.html#ga539fb5b0f1b763dc1cf8d6501160b2ce',1,'initMenu():&#160;menu.c']]]
];
