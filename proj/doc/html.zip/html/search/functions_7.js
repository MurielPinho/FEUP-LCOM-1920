var searchData=
[
  ['kbc_5fread_5fbyte_271',['kbc_read_byte',['../group___p_s2.html#ga25cad6c40137c860e9112ceaffcc9e40',1,'kbc_read_byte(uint8_t port, uint8_t *byte):&#160;ps2.c'],['../group___p_s2.html#ga25cad6c40137c860e9112ceaffcc9e40',1,'kbc_read_byte(uint8_t port, uint8_t *byte):&#160;ps2.c']]],
  ['kbc_5fwrite_5fbyte_272',['kbc_write_byte',['../group___p_s2.html#ga9bff4775ca596880f858eb35f16b4a03',1,'kbc_write_byte(uint8_t port, uint8_t byte):&#160;ps2.c'],['../group___p_s2.html#ga9bff4775ca596880f858eb35f16b4a03',1,'kbc_write_byte(uint8_t port, uint8_t byte):&#160;ps2.c']]],
  ['kbd_5fgame_5finput_273',['kbd_game_input',['../group___keyboard.html#gaafe038c617f6c797bdc3a5f1104d4379',1,'kbd_game_input(int *input, int nPlanets):&#160;keyboard.c'],['../group___keyboard.html#gaafe038c617f6c797bdc3a5f1104d4379',1,'kbd_game_input(int *input, int nPlanets):&#160;keyboard.c']]],
  ['kbd_5fmenu_5finput_274',['kbd_menu_input',['../group___keyboard.html#gafcd311a73433f5a26f9ae4c7eca459fb',1,'kbd_menu_input(int *option):&#160;keyboard.c'],['../group___keyboard.html#gafcd311a73433f5a26f9ae4c7eca459fb',1,'kbd_menu_input(int *option):&#160;keyboard.c']]],
  ['kbd_5fsubscribe_5fint_275',['kbd_subscribe_int',['../group___keyboard.html#gaa7a491d4d95eab5ca5326c4000ad67f8',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c'],['../group___keyboard.html#gaa7a491d4d95eab5ca5326c4000ad67f8',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c']]],
  ['kbd_5funsubscribe_5fint_276',['kbd_unsubscribe_int',['../group___keyboard.html#ga5bdf6cfb570c375192b0d87913b65c57',1,'kbd_unsubscribe_int():&#160;keyboard.c'],['../group___keyboard.html#ga5bdf6cfb570c375192b0d87913b65c57',1,'kbd_unsubscribe_int():&#160;keyboard.c']]]
];
