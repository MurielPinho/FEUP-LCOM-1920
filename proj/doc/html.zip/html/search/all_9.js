var searchData=
[
  ['kbc_5fcmd_5freg_84',['KBC_CMD_REG',['../group___k_b_cboard_macros.html#ga6d57c7927a10f638c83046b52c8caac9',1,'macros.h']]],
  ['kbc_5fin_5fbuf_85',['KBC_IN_BUF',['../group___k_b_cboard_macros.html#gaac9289c99cf0a693a211da6d6cb1bb65',1,'macros.h']]],
  ['kbc_5fn_5ftries_86',['KBC_N_TRIES',['../group___k_b_cboard_macros.html#ga67c6892efd64eaaca11a29adc550f15b',1,'macros.h']]],
  ['kbc_5fout_5fbuf_87',['KBC_OUT_BUF',['../group___k_b_cboard_macros.html#ga1ccde68b2b6d4e45b50eef1403e10bb7',1,'macros.h']]],
  ['kbc_5fread_5fbyte_88',['kbc_read_byte',['../group___p_s2.html#ga25cad6c40137c860e9112ceaffcc9e40',1,'kbc_read_byte(uint8_t port, uint8_t *byte):&#160;ps2.c'],['../group___p_s2.html#ga25cad6c40137c860e9112ceaffcc9e40',1,'kbc_read_byte(uint8_t port, uint8_t *byte):&#160;ps2.c']]],
  ['kbc_5fstat_5freg_89',['KBC_STAT_REG',['../group___k_b_cboard_macros.html#ga34b14687d83496940a236351fbbb1aea',1,'macros.h']]],
  ['kbc_5fwrite_5fbyte_90',['kbc_write_byte',['../group___p_s2.html#ga9bff4775ca596880f858eb35f16b4a03',1,'kbc_write_byte(uint8_t port, uint8_t byte):&#160;ps2.c'],['../group___p_s2.html#ga9bff4775ca596880f858eb35f16b4a03',1,'kbc_write_byte(uint8_t port, uint8_t byte):&#160;ps2.c']]],
  ['kbcmacros_91',['KBCMacros',['../group___k_b_cboard_macros.html',1,'']]],
  ['kbd_5fbit_92',['kbd_bit',['../group___menu.html#ga612045bc323c0d5c4b3f472ceccc59ab',1,'kbd_bit():&#160;menu.c'],['../group___menu.html#ga612045bc323c0d5c4b3f472ceccc59ab',1,'kbd_bit():&#160;menu.c']]],
  ['kbd_5fgame_5finput_93',['kbd_game_input',['../group___keyboard.html#gaafe038c617f6c797bdc3a5f1104d4379',1,'kbd_game_input(int *input, int nPlanets):&#160;keyboard.c'],['../group___keyboard.html#gaafe038c617f6c797bdc3a5f1104d4379',1,'kbd_game_input(int *input, int nPlanets):&#160;keyboard.c']]],
  ['kbd_5fmenu_5finput_94',['kbd_menu_input',['../group___keyboard.html#gafcd311a73433f5a26f9ae4c7eca459fb',1,'kbd_menu_input(int *option):&#160;keyboard.c'],['../group___keyboard.html#gafcd311a73433f5a26f9ae4c7eca459fb',1,'kbd_menu_input(int *option):&#160;keyboard.c']]],
  ['kbd_5fsubscribe_5fint_95',['kbd_subscribe_int',['../group___keyboard.html#gaa7a491d4d95eab5ca5326c4000ad67f8',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c'],['../group___keyboard.html#gaa7a491d4d95eab5ca5326c4000ad67f8',1,'kbd_subscribe_int(uint8_t *bit_no):&#160;keyboard.c']]],
  ['kbd_5funsubscribe_5fint_96',['kbd_unsubscribe_int',['../group___keyboard.html#ga5bdf6cfb570c375192b0d87913b65c57',1,'kbd_unsubscribe_int():&#160;keyboard.c'],['../group___keyboard.html#ga5bdf6cfb570c375192b0d87913b65c57',1,'kbd_unsubscribe_int():&#160;keyboard.c']]],
  ['keyboard_97',['Keyboard',['../group___keyboard.html',1,'']]],
  ['keyboard_5firq_98',['KEYBOARD_IRQ',['../group___k_b_cboard_macros.html#ga2d17911b50c0aeebb2e3325c5b36d4f2',1,'macros.h']]]
];
