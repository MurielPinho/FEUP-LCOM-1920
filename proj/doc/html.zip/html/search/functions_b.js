var searchData=
[
  ['set_5fsprite_5fspeed_289',['set_sprite_speed',['../group___sprite.html#ga10adcb5552bd461c9f61d9cce65b2ea8',1,'set_sprite_speed(Sprite *sprite, int xi, int yi, int xf, int yf, int speed):&#160;sprite.c'],['../group___sprite.html#ga10adcb5552bd461c9f61d9cce65b2ea8',1,'set_sprite_speed(Sprite *sprite, int xi, int yi, int xf, int yf, int speed):&#160;sprite.c']]],
  ['setmousex_290',['setMouseX',['../group___mouse.html#gac80c48cf186b2a56af50096c1ca1f06e',1,'setMouseX(Mouse *mouse, uint16_t x):&#160;mouse.c'],['../group___mouse.html#gac80c48cf186b2a56af50096c1ca1f06e',1,'setMouseX(Mouse *mouse, uint16_t x):&#160;mouse.c']]],
  ['setmousey_291',['setMouseY',['../group___mouse.html#ga361670362d97afbbbdaed486076a84a1',1,'setMouseY(Mouse *mouse, uint16_t y):&#160;mouse.c'],['../group___mouse.html#ga361670362d97afbbbdaed486076a84a1',1,'setMouseY(Mouse *mouse, uint16_t y):&#160;mouse.c']]],
  ['subscribeinterrupts_292',['subscribeInterrupts',['../group___game.html#gadf2b6e369232ab1f8d31374c5f9e6139',1,'subscribeInterrupts():&#160;game.c'],['../group___game.html#gadf2b6e369232ab1f8d31374c5f9e6139',1,'subscribeInterrupts():&#160;game.c']]]
];
