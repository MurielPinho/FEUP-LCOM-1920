var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwxy",
  1: "egmnps",
  2: "cdefghiklmrsuv",
  3: "acdeghiklmnpstvwxy",
  4: "n",
  5: "gmp",
  6: "acegimps",
  7: "gkmpst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules"
};

