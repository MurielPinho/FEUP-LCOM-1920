var searchData=
[
  ['delete_5fmouse_22',['delete_mouse',['../group___mouse.html#ga6f0992f39a6073db60ab60697f049082',1,'delete_mouse(Mouse *mouse):&#160;mouse.c'],['../group___mouse.html#ga6f0992f39a6073db60ab60697f049082',1,'delete_mouse(Mouse *mouse):&#160;mouse.c']]],
  ['dest_23',['dest',['../struct_node_tag.html#a51294a6dd07ea7364261fb9fc428f2a4',1,'NodeTag::dest()'],['../struct_edge.html#ad7df434ff7710e69f28bb31e91a35f82',1,'Edge::dest()']]],
  ['destroy_5fsprite_24',['destroy_sprite',['../group___sprite.html#gaf16c6befaac9ffb673b9e3c798d542ed',1,'destroy_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#gaf16c6befaac9ffb673b9e3c798d542ed',1,'destroy_sprite(Sprite *sp):&#160;sprite.c']]],
  ['direct_5fcolor_5f888_5fmode_25',['DIRECT_COLOR_888_MODE',['../group___graphics_macros.html#gadc188625179884b1bd1ce56975364a93',1,'macros.h']]],
  ['dis_5fkbd_5finterface_26',['DIS_KBD_INTERFACE',['../group___k_b_cboard_macros.html#ga13931a2abf4331f4851f505447dd6847',1,'macros.h']]],
  ['disable_5fdata_5freport_27',['DISABLE_DATA_REPORT',['../group___k_b_cboard_macros.html#gad374b510092499b5961d3771abf9c66e',1,'macros.h']]],
  ['disable_5firq_5fline_28',['DISABLE_IRQ_LINE',['../group___k_b_cboard_macros.html#gaf663bb79da759b50466f1625d464ffa9',1,'macros.h']]],
  ['disable_5fkbd_5finterface_29',['DISABLE_KBD_INTERFACE',['../group___k_b_cboard_macros.html#gaf4de6eb113cbb16e0c04e4eed2e25f9d',1,'macros.h']]],
  ['disable_5fmouse_30',['DISABLE_MOUSE',['../group___k_b_cboard_macros.html#ga12d3b0abea66d191d47fe6860e58865e',1,'macros.h']]],
  ['draw_5fmouse_31',['draw_mouse',['../group___mouse.html#ga3555b6b8e70391041fcc0a29cf1cd638',1,'draw_mouse(Mouse *mouse):&#160;mouse.c'],['../group___mouse.html#ga3555b6b8e70391041fcc0a29cf1cd638',1,'draw_mouse(Mouse *mouse):&#160;mouse.c']]],
  ['draw_5frectangle_32',['draw_rectangle',['../group___graphics.html#gacac59940e880980fe328945b1c9463e4',1,'draw_rectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint32_t color):&#160;graphics.c'],['../group___graphics.html#gacac59940e880980fe328945b1c9463e4',1,'draw_rectangle(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint32_t color):&#160;graphics.c']]],
  ['draw_5fsprite_33',['draw_sprite',['../group___sprite.html#ga6c75fbf31230126d2f19b29deaf24b2f',1,'draw_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#ga6c75fbf31230126d2f19b29deaf24b2f',1,'draw_sprite(Sprite *sp):&#160;sprite.c']]],
  ['drawabout_34',['drawAbout',['../group___menu.html#gac3e5bf1ded69df7bb1282d64d2bfa0a8',1,'drawAbout():&#160;menu.c'],['../group___menu.html#gac3e5bf1ded69df7bb1282d64d2bfa0a8',1,'drawAbout():&#160;menu.c']]],
  ['drawcomplete_35',['drawComplete',['../group___game.html#gab57e067da037457a0a3f6f47ae11e116',1,'drawComplete():&#160;game.c'],['../group___game.html#gab57e067da037457a0a3f6f47ae11e116',1,'drawComplete():&#160;game.c']]],
  ['drawedges_36',['drawEdges',['../group___game.html#ga027105ec7ad9deecc627ab77e27fe68c',1,'drawEdges():&#160;game.c'],['../group___game.html#ga027105ec7ad9deecc627ab77e27fe68c',1,'drawEdges():&#160;game.c']]],
  ['drawend_37',['drawEnd',['../group___game.html#gabd6de31a2cbd9c1609338b0f9095e230',1,'drawEnd():&#160;game.c'],['../group___game.html#gabd6de31a2cbd9c1609338b0f9095e230',1,'drawEnd():&#160;game.c']]],
  ['drawinstructions_38',['drawInstructions',['../group___menu.html#ga0cf97fdd7eb71c16521fedab862db6a3',1,'drawInstructions():&#160;menu.c'],['../group___menu.html#ga0cf97fdd7eb71c16521fedab862db6a3',1,'drawInstructions():&#160;menu.c']]],
  ['drawline_39',['drawLine',['../group___graphics.html#gaf7e874bfc0b998f4b665dc763d60615e',1,'drawLine(uint16_t xi, uint16_t yi, uint16_t xf, uint16_t yf, uint32_t color):&#160;graphics.c'],['../group___graphics.html#gaf7e874bfc0b998f4b665dc763d60615e',1,'drawLine(uint16_t xi, uint16_t yi, uint16_t xf, uint16_t yf, uint32_t color):&#160;graphics.c']]],
  ['drawmenu_40',['drawMenu',['../group___menu.html#gaa13653318c21b0e6b86838e6091bfc9a',1,'drawMenu():&#160;menu.c'],['../group___menu.html#gaa13653318c21b0e6b86838e6091bfc9a',1,'drawMenu():&#160;menu.c']]],
  ['drawmission_41',['drawMission',['../group___game.html#ga67857e604fad85ea53503c492a77a5a9',1,'drawMission():&#160;game.c'],['../group___game.html#ga67857e604fad85ea53503c492a77a5a9',1,'drawMission():&#160;game.c']]],
  ['drawplanets_42',['drawPlanets',['../group___game.html#ga921e5806d08ee6d5118afbbee9636e8f',1,'drawPlanets():&#160;game.c'],['../group___game.html#ga921e5806d08ee6d5118afbbee9636e8f',1,'drawPlanets():&#160;game.c']]]
];
