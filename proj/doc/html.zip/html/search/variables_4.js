var searchData=
[
  ['gstate_311',['gState',['../struct_game.html#afa209aaf1d29ce2b0170c6c3188cc551',1,'Game']]]
];
