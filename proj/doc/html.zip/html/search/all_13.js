var searchData=
[
  ['vbe_5fcall_204',['VBE_CALL',['../group___graphics_macros.html#gaaa7fbe1e02a424af8eb9efc320d936c0',1,'macros.h']]],
  ['vbe_5fcontrol_5finfo_205',['VBE_CONTROL_INFO',['../group___graphics_macros.html#ga58367b07d97797b17b41dd76e3d087c3',1,'macros.h']]],
  ['vbe_5fint_206',['VBE_INT',['../group___graphics_macros.html#ga0ab1b58dbc6c6d4c63156c11f0a4d854',1,'macros.h']]],
  ['vbe_5flinear_5fframe_207',['VBE_LINEAR_FRAME',['../group___graphics_macros.html#gafddba0b511c9732101c7f833d2cd5625',1,'macros.h']]],
  ['vbe_5fmode_5finfo_208',['VBE_MODE_INFO',['../group___graphics_macros.html#ga2ecbf8f92f9322fedec91461747c4843',1,'macros.h']]],
  ['vbe_5fset_5fmode_209',['VBE_SET_MODE',['../group___graphics_macros.html#ga02477c4996ff058aee590b54f2146eb5',1,'macros.h']]],
  ['vbegetmodeinfo_210',['vbeGetModeInfo',['../group___graphics.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;graphics.c'],['../group___graphics.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;graphics.c']]],
  ['vg_5finit_211',['vg_init',['../group___graphics.html#gaa6c1ff5024cd4d15e476bce487584daa',1,'vg_init(uint16_t mode):&#160;graphics.c'],['../group___graphics.html#gaa6c1ff5024cd4d15e476bce487584daa',1,'vg_init(uint16_t mode):&#160;graphics.c']]],
  ['vg_5fset_5fmode_212',['vg_set_mode',['../group___graphics.html#ga3eaed521041b153cd8f9c5d371b393ff',1,'vg_set_mode(uint16_t mode):&#160;graphics.c'],['../group___graphics.html#ga3eaed521041b153cd8f9c5d371b393ff',1,'vg_set_mode(uint16_t mode):&#160;graphics.c']]],
  ['visited_213',['visited',['../struct_node_tag.html#a3fa7eff1149dece575af1ca0898acf91',1,'NodeTag']]],
  ['visitededgecolor_214',['visitedEdgeColor',['../group___settings_macros.html#ga05d726d19fafd9c74565e4ce7bf3a7bf',1,'macros.h']]],
  ['visitedge_215',['visitEdge',['../group___graph.html#ga1a90331a7364d1dec99ab2b90b5e5266',1,'graph.c']]]
];
