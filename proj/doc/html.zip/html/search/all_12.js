var searchData=
[
  ['unsubscribeinterrupts_197',['unsubscribeInterrupts',['../group___game.html#gaab3018278dbad1ab6bfb1696b0ea5b8e',1,'unsubscribeInterrupts():&#160;game.c'],['../group___game.html#gaab3018278dbad1ab6bfb1696b0ea5b8e',1,'unsubscribeInterrupts():&#160;game.c']]],
  ['unvisitededgecolor_198',['unvisitedEdgeColor',['../group___settings_macros.html#ga343cefa497cf8c8c6d6d252a5ffa7ffd',1,'macros.h']]],
  ['update_5fsprite_199',['update_sprite',['../group___sprite.html#gac263d0e18a4429f1ea0158903aa2e6f9',1,'update_sprite(Sprite *sprite, uint16_t xf, uint16_t yf):&#160;sprite.c'],['../group___sprite.html#gac263d0e18a4429f1ea0158903aa2e6f9',1,'update_sprite(Sprite *sprite, uint16_t xf, uint16_t yf):&#160;sprite.c']]],
  ['updatemenuscreen_200',['updateMenuScreen',['../group___menu.html#ga95365def8c62fea30d72ffc8131c5018',1,'updateMenuScreen():&#160;menu.c'],['../group___menu.html#ga95365def8c62fea30d72ffc8131c5018',1,'updateMenuScreen():&#160;menu.c']]],
  ['updatescreen_201',['updateScreen',['../group___game.html#ga192a0a30e5705be3b2800eb7172aa6d4',1,'updateScreen():&#160;game.c'],['../group___game.html#ga192a0a30e5705be3b2800eb7172aa6d4',1,'updateScreen():&#160;game.c']]],
  ['util_5fget_5fbit_202',['util_get_bit',['../group___p_s2.html#ga3885dc8d082f3d4f1207c2dc590bf026',1,'util_get_bit(uint8_t val, uint8_t bit_no):&#160;ps2.c'],['../group___p_s2.html#ga3885dc8d082f3d4f1207c2dc590bf026',1,'util_get_bit(uint8_t val, uint8_t bit_no):&#160;ps2.c']]],
  ['util_5ftwos_5fcomplement_203',['util_twos_complement',['../group___p_s2.html#ga86546b0e548385b211fa6f19562d00d9',1,'util_twos_complement(uint8_t value):&#160;ps2.c'],['../group___p_s2.html#ga86546b0e548385b211fa6f19562d00d9',1,'util_twos_complement(uint8_t value):&#160;ps2.c']]]
];
