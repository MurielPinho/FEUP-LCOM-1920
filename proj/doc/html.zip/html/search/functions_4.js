var searchData=
[
  ['gameinput_265',['gameInput',['../group___game.html#gaad880a39b7e09cb8fee57d05bc60e852',1,'gameInput():&#160;game.c'],['../group___game.html#gaad880a39b7e09cb8fee57d05bc60e852',1,'gameInput():&#160;game.c']]],
  ['gameloop_266',['gameLoop',['../group___game.html#gae3fcb6ab83836a82d8ab58a853667cba',1,'gameLoop():&#160;game.c'],['../group___game.html#gae3fcb6ab83836a82d8ab58a853667cba',1,'gameLoop():&#160;game.c']]]
];
