var searchData=
[
  ['angle_303',['angle',['../struct_sprite.html#ac73574d8b334cc74104cd9e792fac146',1,'Sprite']]]
];
