var searchData=
[
  ['scannedkey_158',['scannedKey',['../group___keyboard.html#gac1186a12b1edbeef26500707faae6106',1,'scannedKey():&#160;keyboard.c'],['../group___keyboard.html#gac1186a12b1edbeef26500707faae6106',1,'scannedKey():&#160;keyboard.c']]],
  ['selectedplanet_159',['selectedPlanet',['../struct_game.html#ae237e3f0917a7e6dca6fc779a932cf7a',1,'Game']]],
  ['selecting_160',['Selecting',['../group___menu.html#ggab59168e7e65e85a345dd7e860b097914aeb1118f2debb0e61f63ca06de1cf5c23',1,'menu.h']]],
  ['set_5fsprite_5fspeed_161',['set_sprite_speed',['../group___sprite.html#ga10adcb5552bd461c9f61d9cce65b2ea8',1,'set_sprite_speed(Sprite *sprite, int xi, int yi, int xf, int yf, int speed):&#160;sprite.c'],['../group___sprite.html#ga10adcb5552bd461c9f61d9cce65b2ea8',1,'set_sprite_speed(Sprite *sprite, int xi, int yi, int xf, int yf, int speed):&#160;sprite.c']]],
  ['setmousex_162',['setMouseX',['../group___mouse.html#gac80c48cf186b2a56af50096c1ca1f06e',1,'setMouseX(Mouse *mouse, uint16_t x):&#160;mouse.c'],['../group___mouse.html#gac80c48cf186b2a56af50096c1ca1f06e',1,'setMouseX(Mouse *mouse, uint16_t x):&#160;mouse.c']]],
  ['setmousey_163',['setMouseY',['../group___mouse.html#ga361670362d97afbbbdaed486076a84a1',1,'setMouseY(Mouse *mouse, uint16_t y):&#160;mouse.c'],['../group___mouse.html#ga361670362d97afbbbdaed486076a84a1',1,'setMouseY(Mouse *mouse, uint16_t y):&#160;mouse.c']]],
  ['settingsmacros_164',['SettingsMacros',['../group___settings_macros.html',1,'']]],
  ['sizeof_5fbyte_165',['SIZEOF_BYTE',['../group___graphics_macros.html#ga46089276d1bd5cfef4e4330d55a08d5f',1,'macros.h']]],
  ['sizeof_5fuint32_166',['SIZEOF_UINT32',['../group___graphics_macros.html#ga2cf658363f61888c8ccf397d78a5d21e',1,'macros.h']]],
  ['speaker_5fctrl_167',['SPEAKER_CTRL',['../group___timer_macros.html#ga51b3a5e3d4811ca063fe25e35560ab40',1,'macros.h']]],
  ['sprite_168',['Sprite',['../struct_sprite.html',1,'Sprite'],['../struct_planet.html#a7a94d391a4539c2b5d909b82c768c6d6',1,'Planet::sprite()'],['../struct_mouse.html#a54c4cb55b4ffea6c1776273b10b0305e',1,'Mouse::sprite()'],['../group___sprite.html',1,'(Global Namespace)']]],
  ['src_169',['src',['../struct_edge.html#a9a415f211c059647d1b3af8fcf7a0e30',1,'Edge']]],
  ['stream_5fmode_170',['STREAM_MODE',['../group___k_b_cboard_macros.html#gab3919f33b46e0808c4ed1c56a6a423f2',1,'macros.h']]],
  ['subscribeinterrupts_171',['subscribeInterrupts',['../group___game.html#gadf2b6e369232ab1f8d31374c5f9e6139',1,'subscribeInterrupts():&#160;game.c'],['../group___game.html#gadf2b6e369232ab1f8d31374c5f9e6139',1,'subscribeInterrupts():&#160;game.c']]]
];
