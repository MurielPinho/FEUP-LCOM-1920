var searchData=
[
  ['x_219',['x',['../struct_planet.html#a6f31a085c4fc9cd33e01c9127d50118b',1,'Planet::x()'],['../struct_sprite.html#a7bf0b8881b843374906cf634fab4c29c',1,'Sprite::x()']]],
  ['x_5fmsb_220',['X_MSB',['../group___k_b_cboard_macros.html#gad9b9b1e1afc532f72e8bb40ebf7fae94',1,'macros.h']]],
  ['x_5fmsb_5fbit_221',['X_MSB_BIT',['../group___k_b_cboard_macros.html#ga87a7ef963bec4bee5e2da90e300cf4d8',1,'macros.h']]],
  ['x_5fov_222',['X_OV',['../group___k_b_cboard_macros.html#gae2c4c6b26ddcdd376d41a1c3d0d1dcad',1,'macros.h']]],
  ['x_5fov_5fbit_223',['X_OV_BIT',['../group___k_b_cboard_macros.html#ga3e737c67b0fca8f51c253e5cde62cb3d',1,'macros.h']]],
  ['xspeed_224',['xspeed',['../struct_sprite.html#a0907b8391344e8a3e4694985d5b7d5ad',1,'Sprite']]]
];
