var searchData=
[
  ['check_5fkbc_9',['CHECK_KBC',['../group___k_b_cboard_macros.html#ga55fefff08c94153a53592686472a6c80',1,'macros.h']]],
  ['check_5fkbd_5finterface_10',['CHECK_KBD_INTERFACE',['../group___k_b_cboard_macros.html#ga747b9afab82ec899413f5415da3d5c4e',1,'macros.h']]],
  ['checkgamestate_11',['checkGameState',['../group___game.html#ga2b8086c17b948486da00732e709362cb',1,'checkGameState():&#160;game.c'],['../group___game.html#ga2b8086c17b948486da00732e709362cb',1,'checkGameState():&#160;game.c']]],
  ['chroma_5fkey_5fgreen_5f888_12',['CHROMA_KEY_GREEN_888',['../group___graphics_macros.html#gaf9f848740c62aebaa9691121703ef6fa',1,'macros.h']]],
  ['clear_5fsprite_13',['clear_sprite',['../group___sprite.html#ga56ed7269b72333472c0a2197dc4daf38',1,'clear_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#ga56ed7269b72333472c0a2197dc4daf38',1,'clear_sprite(Sprite *sp):&#160;sprite.c']]],
  ['clearscreen_14',['clearScreen',['../group___graphics.html#ga9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;graphics.c'],['../group___graphics.html#ga9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;graphics.c']]],
  ['complete_15',['Complete',['../group___game.html#ggaaf29bbe309504beb4cfec2481eacee62ab1efe4af9230e9c8308049f05165c447',1,'game.h']]],
  ['create_5fmouse_16',['create_mouse',['../group___mouse.html#gaabca0b277fb64d95ac7209aed1ec4dbd',1,'create_mouse(uint16_t x, uint16_t y, Sprite *mouse_sprite):&#160;mouse.c'],['../group___mouse.html#gaabca0b277fb64d95ac7209aed1ec4dbd',1,'create_mouse(uint16_t x, uint16_t y, Sprite *mouse_sprite):&#160;mouse.c']]],
  ['create_5fsprite_17',['create_sprite',['../group___sprite.html#gaa4ecfecbe8b45f81c4abe4164757be85',1,'create_sprite(xpm_map_t xpm, int x, int y):&#160;sprite.c'],['../group___sprite.html#gaa4ecfecbe8b45f81c4abe4164757be85',1,'create_sprite(xpm_map_t xpm, int x, int y):&#160;sprite.c']]],
  ['creategame_18',['createGame',['../group___game.html#ga629d3eb48de7cf73518a8f3af68b67ce',1,'createGame():&#160;game.c'],['../group___game.html#ga629d3eb48de7cf73518a8f3af68b67ce',1,'createGame():&#160;game.c']]],
  ['creategraph_19',['createGraph',['../group___graph.html#gaa5deef674cb0ac1e284d822687428ba8',1,'graph.c']]],
  ['createmenu_20',['createMenu',['../group___menu.html#gabcc29a7045854b2d35781fc3b831b331',1,'createMenu():&#160;menu.c'],['../group___menu.html#gabcc29a7045854b2d35781fc3b831b331',1,'createMenu():&#160;menu.c']]],
  ['currentplanet_21',['currentPlanet',['../struct_game.html#ab642d1daa6782271dae06859ffac2944',1,'Game']]]
];
