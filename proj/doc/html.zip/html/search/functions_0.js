var searchData=
[
  ['checkgamestate_240',['checkGameState',['../group___game.html#ga2b8086c17b948486da00732e709362cb',1,'checkGameState():&#160;game.c'],['../group___game.html#ga2b8086c17b948486da00732e709362cb',1,'checkGameState():&#160;game.c']]],
  ['clear_5fsprite_241',['clear_sprite',['../group___sprite.html#ga56ed7269b72333472c0a2197dc4daf38',1,'clear_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#ga56ed7269b72333472c0a2197dc4daf38',1,'clear_sprite(Sprite *sp):&#160;sprite.c']]],
  ['clearscreen_242',['clearScreen',['../group___graphics.html#ga9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;graphics.c'],['../group___graphics.html#ga9d7e8af417b6d543da691e9c0e2f6f9f',1,'clearScreen():&#160;graphics.c']]],
  ['create_5fmouse_243',['create_mouse',['../group___mouse.html#gaabca0b277fb64d95ac7209aed1ec4dbd',1,'create_mouse(uint16_t x, uint16_t y, Sprite *mouse_sprite):&#160;mouse.c'],['../group___mouse.html#gaabca0b277fb64d95ac7209aed1ec4dbd',1,'create_mouse(uint16_t x, uint16_t y, Sprite *mouse_sprite):&#160;mouse.c']]],
  ['create_5fsprite_244',['create_sprite',['../group___sprite.html#gaa4ecfecbe8b45f81c4abe4164757be85',1,'create_sprite(xpm_map_t xpm, int x, int y):&#160;sprite.c'],['../group___sprite.html#gaa4ecfecbe8b45f81c4abe4164757be85',1,'create_sprite(xpm_map_t xpm, int x, int y):&#160;sprite.c']]],
  ['creategame_245',['createGame',['../group___game.html#ga629d3eb48de7cf73518a8f3af68b67ce',1,'createGame():&#160;game.c'],['../group___game.html#ga629d3eb48de7cf73518a8f3af68b67ce',1,'createGame():&#160;game.c']]],
  ['creategraph_246',['createGraph',['../group___graph.html#gaa5deef674cb0ac1e284d822687428ba8',1,'graph.c']]],
  ['createmenu_247',['createMenu',['../group___menu.html#gabcc29a7045854b2d35781fc3b831b331',1,'createMenu():&#160;menu.c'],['../group___menu.html#gabcc29a7045854b2d35781fc3b831b331',1,'createMenu():&#160;menu.c']]]
];
