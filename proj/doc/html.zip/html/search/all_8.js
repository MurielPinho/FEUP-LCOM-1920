var searchData=
[
  ['ibf_76',['IBF',['../group___k_b_cboard_macros.html#ga3c48b10907056351582baf9f6478598e',1,'macros.h']]],
  ['initgame_77',['initGame',['../group___game.html#gaf914d9c0c56eba0cd037f32d5af60cf1',1,'initGame():&#160;game.c'],['../group___game.html#gaf914d9c0c56eba0cd037f32d5af60cf1',1,'initGame():&#160;game.c']]],
  ['initialize_5fpacket_78',['initialize_packet',['../group___p_s2.html#gaf0bd08b578b69f2f91bf42772b0da419',1,'initialize_packet(struct packet *pp, uint8_t packetBytes[]):&#160;ps2.c'],['../group___p_s2.html#gaf0bd08b578b69f2f91bf42772b0da419',1,'initialize_packet(struct packet *pp, uint8_t bytes[]):&#160;ps2.c']]],
  ['initmenu_79',['initMenu',['../group___menu.html#ga539fb5b0f1b763dc1cf8d6501160b2ce',1,'initMenu():&#160;menu.c'],['../group___menu.html#ga539fb5b0f1b763dc1cf8d6501160b2ce',1,'initMenu():&#160;menu.c']]],
  ['instructions_80',['Instructions',['../group___menu.html#ggab59168e7e65e85a345dd7e860b097914a86fde7a60a8f37a076216f35b0ce3bda',1,'menu.h']]],
  ['interruptcounter_81',['interruptCounter',['../group___sprite.html#gaede359188911da0a424054bb60b04af4',1,'interruptCounter():&#160;timer.c'],['../group___sprite.html#gaede359188911da0a424054bb60b04af4',1,'interruptCounter():&#160;timer.c']]],
  ['interruptperframe_82',['interruptPerFrame',['../group___menu.html#ga292bede56084774f53bd59bcd29b2790',1,'interruptPerFrame():&#160;menu.c'],['../group___menu.html#ga292bede56084774f53bd59bcd29b2790',1,'interruptPerFrame():&#160;menu.c']]],
  ['iterator_83',['iterator',['../struct_game.html#a84ff6dd5ba2b0fdc787956fb72a26907',1,'Game']]]
];
