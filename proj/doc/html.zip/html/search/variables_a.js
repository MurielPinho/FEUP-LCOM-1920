var searchData=
[
  ['nedges_328',['nEdges',['../struct_mission.html#a8d583dc737fdf4faa8b49e72d80b2caa',1,'Mission']]],
  ['next_329',['next',['../struct_node_tag.html#ab7ff9c5937d69d117fb8b55024567ff7',1,'NodeTag']]],
  ['nplanets_330',['nPlanets',['../struct_mission.html#a58dc67f913e7a75795a147ae1bd188ba',1,'Mission']]],
  ['nvisitededges_331',['nVisitedEdges',['../struct_game.html#a85e53f3a3402f329bc182083f82d027c',1,'Game']]]
];
