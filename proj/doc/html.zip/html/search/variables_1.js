var searchData=
[
  ['currentplanet_304',['currentPlanet',['../struct_game.html#ab642d1daa6782271dae06859ffac2944',1,'Game']]]
];
