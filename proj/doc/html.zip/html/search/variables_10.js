var searchData=
[
  ['x_341',['x',['../struct_planet.html#a6f31a085c4fc9cd33e01c9127d50118b',1,'Planet::x()'],['../struct_sprite.html#a7bf0b8881b843374906cf634fab4c29c',1,'Sprite::x()']]],
  ['xspeed_342',['xspeed',['../struct_sprite.html#a0907b8391344e8a3e4694985d5b7d5ad',1,'Sprite']]]
];
