var searchData=
[
  ['selecting_358',['Selecting',['../group___menu.html#ggab59168e7e65e85a345dd7e860b097914aeb1118f2debb0e61f63ca06de1cf5c23',1,'menu.h']]]
];
